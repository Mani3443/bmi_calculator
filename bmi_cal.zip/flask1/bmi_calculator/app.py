from flask import Flask, render_template, request
# HERE THE FLASK IS THE MAIN CLASS OF THE FRAMEWORK WHERE IT HELPS US TO CREATE WEB APPLICATION
# THE RENDER_TEMPLATE IS USED TAKE THE HTML TEMPLATES AND HELPS TO DISPLAY
# THE REQUEST IS USED TO HANDLE THE REQUESTS LIKE THE HTTP
app = Flask(__name__)
# THE ABOVE IS USED FOR THE REPRESENTATION OF OUR APPLICATION FROM HERE THE CREATION OF A FLASK STARTS
@app.route('/')
#the above @app.route('/') is used to help us in providing the location of the home page
def index():
    return render_template('bmi.html')
# THE ABOVE IS USED TO HANDLE THE REQUEST AND TO DISPLAY THE HTML TEMPLATES
@app.route('/calculate', methods=['POST'])
# when the user submits the data then these is used to send the data to the calculate function and to post the result according to the method used in the methods like get,post,delete..etc
def calculate():
    #these calculate function is used to perform the actions in finding out the bmi value
    weight = float(request.form.get('weight'))
    height = float(request.form.get('height')) / 100  # THESE HEIGHT EQ IS USED TO CONVERT THE CM INTO M
    bmi = weight / (height ** 2)
    bmi="{:.7f}".format(bmi)
    return render_template('result.html', bmi=bmi)
# and the output is displayed in the result.html template after the calculation of the bmi value when the user clicks the submit button
if __name__ == '__main__':
    # the above hepls us to run the application when script is executed
    app.run(debug=True)
    #the above is used to enble the debug mode of the flask application